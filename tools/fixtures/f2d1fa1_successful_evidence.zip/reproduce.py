"""Produce native accepted historical evidence under the exact f2d1fa1 package."""
import json
import platform
import sys
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
import CliPP2
import numpy, scipy, pandas
from CliPP2.io.data import content_hash
from CliPP2.simulation.design import make_contract, jobs, workflow_config
from CliPP2.simulation.study import _prepare_histories, _run_cell, save_json, report, _paired_result
from CliPP2.simulation.reporting import reevaluate_cell
root = Path(sys.argv[1])
root.mkdir()
baseline=Path(sys.argv[2])
installed=Path(CliPP2.__file__).parent
compared=[]
for source in sorted(baseline.rglob('*')):
    if source.is_file() and source.suffix in {'.py','.h','.cpp','.cu','.cuh'}:
        relative=source.relative_to(baseline)
        assert source.read_bytes()==(installed/relative).read_bytes(), str(relative)
        compared.append(str(relative))
contract=make_contract(master_seed=20261105,workers=1,mutations=12,segments=2,regions=2,
                       main_histories=1,development_histories=1)
contract['families']=['S01']
job=next(row for row in jobs(contract,'main',1) if row['family']=='S01' and row['acquisition']['id']=='A2')
config=workflow_config()
evaluation_config=dict(reference_match_atol=.05,reference_distance='l2')
contract['evaluation'].update(evaluation_config)
save_json(root/'study_contract.json',contract)
save_json(root/'allocation.json',dict(planned_main_datasets=1,main_histories_per_family=1))
roster=dict(schema='clipp2.simulation-roster.v1',families=['S01'],jobs=[job])
save_json(root/'main_roster.json',dict(roster,roster_id=content_hash(roster)))
save_json(root/'job_manifests/batch-001.json',[job])
_prepare_histories(root,[job])
cell=_run_cell(dict(root=str(root),job=job,execution_configs=[asdict(config)],archive_completed=True,
                   **evaluation_config))
print(cell['status'], flush=True)
assert cell['status']=='complete',cell
paired=_paired_result(root/cell['attempt'],1)
assert paired['status']=='complete',paired
cached=json.loads((root/cell['evaluations'][0]).read_text())
derived=reevaluate_cell(root,cell,evaluation_config)
assert derived['status']=='derived_from_preserved_evidence',derived
assert cached['evaluation_definition']==derived['evaluation_definition']
assert cached['metrics']==derived['metrics']
with patch('CliPP2.simulation.figures.make_figures',return_value=[]):
    report(root,report_dir=str(root.parent/(root.name+'-cached-report')))
    report(root,evaluation_config=evaluation_config,report_dir=str(root.parent/(root.name+'-derived-report')))
save_json(root/'fixture_origin.json',dict(
 producer_revision='f2d1fa1b09dee8b363078f8cc7ab22a6a5263522',
 package_source_files_byte_equal_to_revision_archive=len(compared),
 generation='Actual retained f2d1fa1 package, S01 physical history/acquisition and all native accepted fitting/assignment stages',
 native_fit_count=paired['cost_ledger']['fit_count'],assignment_passes=paired['cost_ledger']['assignment_pass_count'],
 dimensions=job['dimensions'], source_catalog_schema='clipp2.original-catalog.v3',
 environment=dict(python=sys.version,platform=platform.platform(),numpy=numpy.__version__,scipy=scipy.__version__,pandas=pandas.__version__),
 workflow_config=asdict(config), evaluation_config=evaluation_config,
 expected_evaluation_definition=cached['evaluation_definition'],
 expected_metrics=[m for m in cached['metrics'] if m['arm'] in ('B3','C3') and m['stratum']=='all'
   and m['name'] in ('binary_correct_per_original_evaluable','binary_correct_resolution',
                    'binary_unchanged_population_membership_error','binary_brier','binary_log_loss')],
 expected_population_per_arm={key:paired['arms']['B']['counts'][key] for key in
   ('Ncombined','K','T','F','retained_clonal','unresolved')},
 comparison_policy='Same preserved evaluation.v3 definition, L2 reference distance, match tolerance0.05. Discrete fields exact; recomputed floats rtol1e-12,atol1e-15.',
 reproduce_command='OLD_ENV/bin/python reproduce.py NEW_OUTPUT_DIRECTORY /path/to/f2d1fa1/src/CliPP2',
 baseline_reevaluation_status=derived['status'],baseline_truth_qualification=derived['truth_qualification'],
 baseline_cached_report='passed',baseline_explicit_reevaluation='passed',
 reproducer='reproduce.py'))
